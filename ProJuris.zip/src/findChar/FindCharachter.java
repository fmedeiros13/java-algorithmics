/**
 * 
 */
package findChar;

/**
 * @author Fernando Correa de Medeiros
 * 
 * @see findChar.MyFindCharachter
 *
 */
public interface FindCharachter {
	
	char findChar(String word);	

}

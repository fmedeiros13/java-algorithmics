/**
 * 
 */
package findarray2;

/**
 * @author Fernando Correa de Medeiros
 * 
 * @see findarray2.MyFindArray
 *
 */
public interface FindArray {
	
	int findArray(int[] array, int[] subArray);	

}
